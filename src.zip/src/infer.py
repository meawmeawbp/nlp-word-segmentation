# src/infer.py
def predict(model, tokenizer, inputs, max_length=256):
    results = []
    for text in inputs:
        input_ids = tokenizer(text, return_tensors="pt").input_ids
        output_ids = model.generate(input_ids, max_length=max_length)
        prediction = tokenizer.decode(output_ids[0], skip_special_tokens=True)
        results.append(prediction)
    return results
