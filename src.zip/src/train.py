# src/train.py
from transformers import T5Tokenizer, T5ForConditionalGeneration, Trainer, TrainingArguments
from src.dataset import WordSegDataset

def train_model(train_inputs, train_outputs):
    tokenizer = T5Tokenizer.from_pretrained("t5-small")
    model = T5ForConditionalGeneration.from_pretrained("t5-small")

    dataset = WordSegDataset(tokenizer, train_inputs, train_outputs)

    training_args = TrainingArguments(
        output_dir="./models",
        per_device_train_batch_size=4,
        num_train_epochs=4,
        logging_dir="./models/logs",
        save_steps=200,
        logging_steps=50,
        fp16=True,
        report_to="none"
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=dataset
    )

    trainer.train()
    model.save_pretrained("models/t5_ws")
    tokenizer.save_pretrained("models/t5_ws")

    return model, tokenizer
