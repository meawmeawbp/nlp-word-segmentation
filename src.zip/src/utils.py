# src/utils.py
def load_ws_list(path):
    inputs, outputs = [], []
    with open(path, encoding='utf-8') as f:
        for line in f:
            output = line.strip()
            input_ = output.replace(" ", "")
            inputs.append(input_)
            outputs.append(output)
    return inputs, outputs

def load_ws_test(path):
    with open(path, encoding='utf-8') as f:
        return [line.strip() for line in f]
